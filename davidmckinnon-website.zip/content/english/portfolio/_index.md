---
title: "Portfolio"
meta_title: "David McKinnon's Business Portfolio | Current & Alumni Ventures"
description: "Explore David McKinnon's diverse business portfolio spanning investment, healthcare, beauty, lifestyle, and technology across current ventures and successful exits."
image: "/images/davidmckinnon-headshot.png"
draft: false
---